<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <h3>Perfil</h3>
    <form class="" action="comprobar.php" method="post" onsubmit="return comprobar();">
      Dame tu nombre:
      <input type="text" name="nombre" value="" id="nombre">
      <br><br>
      Nº de Personas:
      <input type="text" name="numero" value="" id="numero">
      <input type="submit" name="" value="Enviar"></input>
    </form>

    <script src="comprobar.js" charset="utf-8"></script>
  </body>
</html>
