function comprobar() {
  let nombre=document.getElementById('nombre').value;
  let numero=document.getElementById('numero').value;

  if (nombre.length==0) {
    alert("El campo Nombre esta vacio");
    return false;

  }else if (numero=="") {
    alert("El campo Numero no hay nada");
    return false;

  }else if (isNaN(numero)){
    alert("El campo Numero no es un numero");
    return false;

  }else {
    alert("todo bien")
  }
}
